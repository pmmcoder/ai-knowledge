#!/usr/bin/env python3
"""校验上手报告的证据是否可解析到真实文件与行。

只做机械校验，不判断内容对错：
  1. 每条 file 证据的路径存在、行号在范围内、该行非空
  2. 正文引用的每个 [E..] 都能在索引 (#evidence-index) 中找到
  3. 索引中的每个条目都至少被正文引用一次
  4. 每条证据的 claim 非空
  5. Mermaid 源码里没有裸 `<` 或裸 `&`（会被 HTML 解析器吃掉，图渲染失败）

用法: python3 verify_evidence.py <report.html> [repo_root]
退出码: 0 通过；1 存在失败项；2 用法或解析错误
依赖: Python 3 标准库。
"""

import json
import os
import re
import sys

INDEX_RE = re.compile(
    r'<script[^>]*type=["\']application/json["\'][^>]*id=["\']evidence-index["\'][^>]*>(.*?)</script>',
    re.S | re.I,
)
REF_RE = re.compile(r"\[(E\d+)\]")
MERMAID_RE = re.compile(r'<pre[^>]*class=["\'][^"\']*mermaid[^"\']*["\'][^>]*>(.*?)</pre>', re.S | re.I)
BARE_LT_RE = re.compile(r"<(?![bB][rR]\s*/?>)")
BARE_AMP_RE = re.compile(r"&(?!(amp|lt|gt|quot|apos|#\d+|#x[0-9a-fA-F]+);)")


def check_mermaid(html):
    """Mermaid 的源码会被浏览器当 HTML 解析：裸 < 会被当成标签吞掉，
    而 mermaid.run() 读的是 innerHTML，拿到的是残缺内容，于是渲染报语法错误。
    这里提前拦下来，比在浏览器里排查便宜得多。"""
    bad = []
    for i, block in enumerate(MERMAID_RE.findall(html), 1):
        for n, line in enumerate(block.splitlines(), 1):
            if BARE_LT_RE.search(line):
                bad.append(f"第 {i} 张 Mermaid 图第 {n} 行含裸 '<'（会被 HTML 解析器吞掉）：{line.strip()[:80]}")
            elif BARE_AMP_RE.search(line):
                bad.append(f"第 {i} 张 Mermaid 图第 {n} 行含裸 '&'（应写成 &amp;）：{line.strip()[:80]}")
    return bad


def main():
    argv = sys.argv[1:]
    if not argv or argv[0] in ("-h", "--help"):
        print("用法: python3 verify_evidence.py <report.html> [repo_root]")
        return 2 if not argv else 0

    report = os.path.abspath(argv[0])
    if not os.path.isfile(report):
        print(f"报告不存在: {report}", file=sys.stderr)
        return 2
    repo = os.path.abspath(argv[1]) if len(argv) > 1 else os.path.dirname(os.path.dirname(report))

    html = open(report, encoding="utf-8").read()
    mermaid_failures = check_mermaid(html)
    m = INDEX_RE.search(html)
    if not m:
        print('未找到 <script type="application/json" id="evidence-index"> 证据索引块', file=sys.stderr)
        return 2
    try:
        index = json.loads(m.group(1))
    except json.JSONDecodeError as e:
        print(f"证据索引不是合法 JSON: {e}", file=sys.stderr)
        return 2

    body = html.replace(m.group(0), "")   # 去掉索引块本身，避免把索引里的编号算成正文引用
    failures, warnings, manual = list(mermaid_failures), [], []
    counts = {"file": 0, "command": 0}
    seen = set()

    for entry in index:
        eid = str(entry.get("id", "")).strip()
        if not re.fullmatch(r"E\d+", eid):
            failures.append(f"索引条目 id 非法（应为 E+数字）: {entry.get('id')!r}")
            continue
        if eid in seen:
            failures.append(f"证据编号重复: {eid}")
        seen.add(eid)
        claim = str(entry.get("claim") or "").strip()
        if not claim:
            failures.append(f"{eid} 缺少 claim（这条证据支撑什么结论）")

        kind = entry.get("kind")
        if kind == "file":
            counts["file"] += 1
            rel = str(entry.get("path") or "").strip()
            if not rel:
                failures.append(f"{eid} kind=file 但缺少 path")
                continue
            path = os.path.join(repo, rel)
            if not os.path.isfile(path):
                failures.append(f"{eid}  路径不存在: {rel}")
                continue
            try:
                content = open(path, encoding="utf-8", errors="replace").read()
            except OSError as e:
                failures.append(f"{eid}  无法读取 {rel}: {e}")
                continue
            lines = content.split("\n")
            if lines and lines[-1] == "":
                lines.pop()
            ln = entry.get("line")
            if not isinstance(ln, int) or ln < 1:
                failures.append(f"{eid}  {rel} 缺少合法行号（line 应为 >=1 的整数）")
                continue
            if ln > len(lines):
                failures.append(f"{eid}  {rel}:{ln} 行号超出范围（该文件共 {len(lines)} 行）")
                continue
            if not lines[ln - 1].strip():
                failures.append(f"{eid}  {rel}:{ln} 该行为空，指不到有效证据")
                continue
        elif kind == "command":
            counts["command"] += 1
            cmd = str(entry.get("command") or "").strip()
            if not cmd:
                failures.append(f"{eid} kind=command 但缺少 command")
                continue
            manual.append(f"{eid}  {cmd}  →  {entry.get('result') or '(未记录结果摘要)'}")
        else:
            failures.append(f"{eid} kind 必须是 file 或 command，实际为 {entry.get('kind')!r}")

    referenced = set(REF_RE.findall(body))
    for eid in sorted(referenced, key=lambda s: int(s[1:])):
        if eid not in seen:
            failures.append(f"正文引用了索引中不存在的编号: [{eid}]")
    for eid in sorted(seen - referenced, key=lambda s: int(s[1:])):
        warnings.append(f"{eid} 已在索引中，但正文从未引用")

    shown = os.path.relpath(report)
    print(f"证据校验: {report if shown.startswith('..') else shown}")
    print(f"仓库根:   {repo}")
    print(f"索引条目: {len(index)}（file {counts['file']} / command {counts['command']}）")
    print(f"正文引用: {len(referenced)} 个编号")
    print(f"Mermaid 图: {len(MERMAID_RE.findall(html))} 张，裸字符问题 {len(mermaid_failures)} 处")

    if manual:
        print(f"\n需人工复核（command 证据，脚本无法自动验证 {len(manual)} 条）:")
        for x in manual:
            print(f"  - {x}")
    if warnings:
        print(f"\n提示（{len(warnings)} 条）:")
        for w in warnings:
            print(f"  - {w}")
    if failures:
        print(f"\n失败 {len(failures)} 条:", file=sys.stderr)
        for f in failures:
            print(f"  - {f}", file=sys.stderr)
        print("\n证据校验未通过：修报告后重跑，不要跳过。", file=sys.stderr)
        return 1

    print("\n证据校验通过：所有文件证据均可解析到真实存在的非空行。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
