#!/usr/bin/env python3
"""采集与语言、框架无关的仓库骨架事实。

只输出"文件存不存在"级别的事实，不读内容语义、不猜路由、不猜环境变量、不猜端口。
语义判断交给使用者读代码，本工具只负责指路。

用法: python3 collect_facts.py [repo_root] [out_file]
依赖: Python 3 标准库（无第三方包）；git 可选。
"""

import os
import re
import subprocess
import sys
import time

PRUNE_DIRS = {
    "node_modules", ".git", "dist", "build", "out", "target", ".venv", "venv", "vendor",
    "__pycache__", ".next", ".nuxt", "coverage", ".cache", "Pods", ".gradle", ".idea",
    ".vscode", ".mypy_cache", ".pytest_cache", ".tox", ".terraform", ".svn", ".hg",
}

MANIFESTS = [
    "package.json", "go.mod", "pom.xml", "build.gradle", "build.gradle.kts", "settings.gradle",
    "Cargo.toml", "pyproject.toml", "setup.py", "requirements.txt", "composer.json", "Gemfile",
    "mix.exs", "pubspec.yaml", "Package.swift", "deno.json", "build.sbt", "CMakeLists.txt",
    "Makefile", "*.csproj", "*.sln",
]
LOCKS = [
    "package-lock.json", "pnpm-lock.yaml", "yarn.lock", "bun.lockb", "go.sum", "poetry.lock",
    "uv.lock", "Cargo.lock", "composer.lock", "Gemfile.lock", "Podfile.lock",
    "packages.lock.json", "requirements.lock",
]
CI = [
    ".gitlab-ci.yml", "Jenkinsfile", "bitbucket-pipelines.yml", "azure-pipelines.yml",
    "cloudbuild.yaml", "buildspec.yml", "Taskfile.yml", "Taskfile.yaml", "justfile",
]
CONTAINER = [
    "Dockerfile", "Dockerfile.*", "docker-compose.yml", "docker-compose.yaml", "compose.yml",
    "compose.yaml", "Procfile", "app.yaml", "serverless.yml", "fly.toml", "vercel.json",
    "netlify.toml", "firebase.json", ".firebaserc", "Chart.yaml", "skaffold.yaml", "*.tf",
]
ENV_FILES = [
    ".env", ".env.*", "env.example", "*.env", "config.yaml", "config.yml", "config.toml",
    "config.json", "application.properties", "application.yml", "application.yaml",
]
ENTRIES = [
    "main.go", "main.rs", "main.py", "app.py", "manage.py", "wsgi.py", "asgi.py", "server.py",
    "index.ts", "index.js", "index.mjs", "main.ts", "main.js", "app.ts", "app.js",
    "Application.java", "Program.cs", "Startup.cs", "main.rb", "config.ru", "index.php",
    "artisan", "bootstrap.dart", "lib.rs",
]
LAYOUT_DIRS = [
    "src", "app", "pkg", "internal", "cmd", "lib", "api", "server", "services", "handlers",
    "routes", "config", "core", "controllers", "models", "schemas", "migrations",
    "tests", "test", "spec", "docs",
]
# 设计意图类文档：按路径关键字匹配（小写），只列路径，内容是否可信由使用者读后判断
DESIGN_DOC_KEYWORDS = ["adr", "decision", "design", "architecture", "rfc", "proposal", "spec", "contributing"]
DOC_EXTS = (".md", ".rst", ".txt", ".adoc")


def norm(path):
    return os.path.normpath(path).replace(os.sep, "/")


def walk(root, prune_self, max_depth, max_entries=None):
    """广度受限遍历，返回相对路径列表（已排除依赖/产物目录与本技能自身）。"""
    root = norm(root)
    out = []
    root_depth = root.rstrip("/").count("/")
    for dirpath, dirnames, filenames in os.walk(root):
        depth = norm(dirpath).count("/") - root_depth
        dirnames[:] = sorted(
            d for d in dirnames if d not in PRUNE_DIRS and d != prune_self and not d.startswith(".")
        )
        if depth >= max_depth:
            dirnames[:] = []
        for fn in sorted(filenames):
            full = norm(os.path.join(dirpath, fn))
            rel = full[len(root) + 1:] if full.startswith(root + "/") else full
            if prune_self and prune_self in rel.split("/"):
                continue
            out.append(rel)
        if max_entries and len(out) > max_entries * 4:
            break
    return out


def match(files, patterns):
    import fnmatch
    hits = []
    for rel in files:
        base = os.path.basename(rel)
        for p in patterns:
            if fnmatch.fnmatch(base, p):
                hits.append(rel)
                break
    return sorted(hits)


def sh(cmd, cwd):
    try:
        return subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=20).stdout.strip()
    except Exception:
        return ""


def main():
    repo = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else os.getcwd())
    if not os.path.isdir(repo):
        print(f"repo_root 不存在: {repo}", file=sys.stderr)
        return 2
    name = os.path.basename(repo)
    out_path = sys.argv[2] if len(sys.argv) > 2 else os.path.join(
        os.environ.get("TMPDIR", "/tmp"), f"onboarding-facts-{name}.txt")

    self_dir = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
    prune_self = os.path.basename(self_dir) if self_dir.startswith(repo + os.sep) else None

    files = walk(repo, prune_self, 4)
    lines = []
    add = lines.append

    add("")
    add("===== META =====")
    add(f"repo_root: {norm(repo)}")
    add(f"collected_at: {time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}")
    add("collected_by: collect_facts.py (只做文件级事实，不做语义判断)")
    commit = sh(["git", "rev-parse", "HEAD"], repo)
    add(f"git_commit: {commit or 'UNKNOWN (not a git work tree)'}")
    if commit:
        add(f"git_branch: {sh(['git', 'rev-parse', '--abbrev-ref', 'HEAD'], repo) or 'UNKNOWN'}")
        add(f"git_dirty_files: {len([l for l in sh(['git', 'status', '--porcelain'], repo).splitlines() if l.strip()])}")
        add(f"git_remote: {sh(['git', 'remote', '-v'], repo).split()[1] if sh(['git','remote','-v'],repo) else 'UNKNOWN'}")

    add("\n===== TOP_LEVEL_ENTRIES =====")
    try:
        lines.extend(sorted(os.listdir(repo)))
    except OSError as e:
        add(f"(读取失败: {e})")

    add("\n===== DIRECTORY_TREE (depth<=3) =====")
    tree = walk(repo, prune_self, 3)
    for rel in sorted(tree):
        add(rel)
    if not tree:
        add("(空)")

    def section(title, patterns, note=None):
        add(f"\n===== {title} =====")
        if note:
            add(note)
        hits = match(files, patterns)
        if hits:
            lines.extend(hits)
        else:
            add("(未发现)")

    section("MANIFESTS (依赖清单，只列路径)", MANIFESTS)
    section("LOCKFILES (锁文件，只列路径)", LOCKS)
    section("CI_AND_CD (只列路径)", CI)
    ci_dirs = [d for d in (".github/workflows", ".circleci", ".buildkite") if os.path.isdir(os.path.join(repo, d))]
    if ci_dirs:
        for d in ci_dirs:
            for rel in sorted(walk(os.path.join(repo, d), prune_self, 1)):
                add(rel)
    section("CONTAINER_AND_DEPLOY (只列路径)", CONTAINER)
    section("ENV_AND_CONFIG_FILES (只列路径)", ENV_FILES)
    section("ENTRY_CANDIDATES (仅候选，真实入口需读代码确认)", ENTRIES)

    add("\n===== SOURCE_LAYOUT (顶层目录，供判断分层) =====")
    found = [f"{d}/" for d in LAYOUT_DIRS if os.path.isdir(os.path.join(repo, d))]
    lines.extend(found or ["(无常见源码目录)"])

    section("DOCS (只列路径)", ["*.md", "*.rst", "*.txt"])

    add("\n===== DESIGN_DOCS (设计意图线索，只列路径；是否为「声明的意图」需读后判断) =====")
    def is_design_doc(rel):
        if not rel.lower().endswith(DOC_EXTS):
            return False
        tokens = re.split(r"[/._\-\s]+", rel.lower())
        return any(t.startswith(k) for t in tokens for k in DESIGN_DOC_KEYWORDS)

    design = sorted(rel for rel in files if is_design_doc(rel))
    lines.extend(design or ["(未发现)"])

    add("\n===== HOW_TO_USE =====")
    add("""本文件只提供"文件存不存在"级别的事实，不含任何语义判断。下一步由使用者完成：
1. 读清单与锁文件 → 技术栈与依赖（版本以锁文件为准）。
2. 读 CI / 容器 / 部署配置 / env 文件 / 启动脚本 → 启动方式与所需参数。
3. 读入口候选与源码顶层目录 → 找到真实入口，顺代码往下读，得到接口清单与环境变量。
   （本工具不探测路由与环境变量：那需要理解框架语义，正则做不到且换框架即失效。）
4. 读 DESIGN_DOCS 与代码注释 → 找「声明的意图」；再读代码找跨文件反复出现的做法 → 「推断的意图」。
   （本工具不识别设计模式：只能读代码判断。）
5. 每条结论都要落到 文件:行号，并用 check_report.py 校验。""")

    text = "\n".join(lines) + "\n"
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(text)
    print(f"FACTS_FILE={out_path}")
    print(f"SECTIONS={text.count('=====')}  LINES={len(text.splitlines())}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
