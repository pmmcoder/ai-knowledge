#!/usr/bin/env python3
"""产出后检查：一条命令回答「这份报告能不能交付」。

三组检查，全部机械可判定：
  A 证据门   —— 调用 verify_evidence.py（路径/行号/引用完整 + Mermaid 裸字符）
  B 结构门   —— 上手层 5 块是否齐、核心流程是否 3–5 张且标注判据；
                架构解读层 7 块是否齐、决策/思想/偏离/评价的结构化字段是否合规；
                参考层 6 块是否齐、覆盖范围声明与未确认清单是否非空
  C 渲染门   —— （--render）用本机浏览器把每张 Mermaid 图真的渲染一遍，
                检查是否产出了 SVG、有没有 Parse error；无浏览器或无网络时明确报「跳过」

用法:
  python3 check_report.py <report.html> [repo_root]
  python3 check_report.py <report.html> [repo_root] --render
退出码: 0 全部通过（跳过项不算失败）；1 有失败；2 用法或读取错误
依赖: Python 3 标准库；--render 额外需要本机 Chrome / Chromium / Edge（联网加载 Mermaid CDN）
"""

import argparse
import json
import os
import pathlib
import re
import shutil
import subprocess
import sys
import tempfile

HERE = pathlib.Path(__file__).resolve().parent
VERIFY = HERE / "verify_evidence.py"

MERMAID_RE = re.compile(r'<pre[^>]*class=["\'][^"\']*mermaid[^"\']*["\'][^>]*>(.*?)</pre>', re.S | re.I)
BARE_LT_RE = re.compile(r"<(?![bB][rR]\s*/?>)")
BARE_AMP_RE = re.compile(r"&(?!(amp|lt|gt|quot|apos|#\d+|#x[0-9a-fA-F]+);)")

L1_SECTIONS = [("overview", "一句话定位"), ("run", "怎么跑起来"), ("structure", "代码结构"),
               ("architecture", "架构总览"), ("core-flows", "核心流程")]
L2_SECTIONS = [("interfaces", "全部接口清单"), ("deps", "依赖明细"), ("config", "参数与配置"),
               ("coverage", "覆盖范围声明"), ("evidence", "证据索引"), ("unknowns", "未确认清单")]
CRITERIA_RE = re.compile(r"命中判据\s*(?:<span[^>]*>)?\s*C[1-4]")

INTERP_SECTIONS = [("constraints", "问题域与约束"), ("arch-intent", "架构意图"), ("decisions", "关键设计决策"),
                   ("ideas", "核心思想"), ("abstractions", "关键抽象"), ("deviations", "意图与实现的偏离"),
                   ("verdicts", "评价")]
INTENTS = {"declared", "inferred"}
FITS = {"fit": "合适", "risky": "有隐患", "unfit": "已不合适"}
DECISION_FIELDS = ("约束", "决策", "备选方案", "代价")
VERDICT_FIELDS = ("评价对象", "适配度", "依据", "触发条件")
EV_REF_RE = re.compile(r"\[(E\d+)\]")


def text_of(fragment):
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", fragment)).strip()


def attr(attrs, name):
    m = re.search(r'\b%s="([^"]*)"' % re.escape(name), attrs)
    return m.group(1) if m else None


def tagged(fragment, tag, cls):
    """返回 [(attrs, body)]：指定 tag 且 class 含 cls 的元素（不处理同名嵌套）。"""
    pat = r'<%s\b([^>]*\bclass="(?:[^"]*\s)?%s(?:\s[^"]*)?"[^>]*)>(.*?)</%s>' % (tag, re.escape(cls), tag)
    return re.findall(pat, fragment, re.S)


def dl_fields(body):
    return {text_of(dt): (dd, text_of(dd)) for dt, dd in
            re.findall(r"<dt[^>]*>(.*?)</dt>\s*<dd[^>]*>(.*?)</dd>", body, re.S)}


def load_evidence(html):
    m = re.search(r'<script[^>]*id=["\']evidence-index["\'][^>]*>(.*?)</script>', html, re.S)
    if not m:
        return {}
    try:
        return {e.get("id"): e for e in json.loads(m.group(1)) if isinstance(e, dict)}
    except (json.JSONDecodeError, TypeError):
        return {}  # 证据门会报 JSON 问题，这里不重复


def links(fragment, prefix):
    return set(re.findall(r'href="#(%s\d+)"' % prefix, fragment))


def check_interpretation(html):
    """架构解读层：7 块 + 决策 / 思想 / 偏离 / 评价的结构化字段。"""
    fails, notes = [], []
    m = re.search(r'<details[^>]*class="(?:[^"]*\s)?interp(?:\s[^"]*)?"[^>]*>(.*?)</details>', html, re.S)
    if not m:
        return ["缺少架构解读层（<details class=\"interp\">）"], notes
    inner = m.group(1)

    for sec_id, name in INTERP_SECTIONS:
        if f'id="{sec_id}"' not in inner:
            fails.append(f"架构解读层缺少区块：{name}（#{sec_id}），或不在折叠层内")

    flows_pos = html.find('id="core-flows"')
    refs_m = re.search(r'<details[^>]*class="[^"]*refs', html)
    if flows_pos >= 0 and m.start() < flows_pos:
        fails.append("架构解读层应位于上手层（核心流程）之后")
    if refs_m and m.start() > refs_m.start():
        fails.append("架构解读层应位于参考层之前")

    evidence = load_evidence(html)

    # 1 约束
    cons = section_html(inner, "constraints") or ""
    k_ids = set()
    items = tagged(cons, "li", "constraint")
    if not items:
        fails.append("问题域与约束：没有任何 li.constraint 条目")
    for attrs, body in items:
        kid = attr(attrs, "id") or "?"
        if not re.fullmatch(r"K\d+", kid):
            fails.append(f"约束条目 id 应为 K1、K2…，实际为「{kid}」")
        k_ids.add(kid)
        if not EV_REF_RE.search(body):
            fails.append(f"约束 {kid} 没有挂证据")

    # 3 决策
    decs = section_html(inner, "decisions") or ""
    arts = tagged(decs, "article", "decision")
    dec_ids = set()
    if not (3 <= len(arts) <= 6):
        fails.append(f"关键设计决策为 {len(arts)} 条，规范要求 3–6 条")
    for attrs, body in arts:
        did = attr(attrs, "id") or "?"
        dec_ids.add(did)
        if not re.fullmatch(r"DEC\d+", did):
            fails.append(f"决策 id 应为 DEC1、DEC2…，实际为「{did}」")
        if attr(attrs, "data-intent") not in INTENTS:
            fails.append(f"决策 {did} 的 data-intent 必须是 declared / inferred")
        fields = dl_fields(body)
        for f in DECISION_FIELDS:
            if f not in fields or not fields[f][1]:
                fails.append(f"决策 {did} 缺少或空着字段「{f}」")
        if "约束" in fields and not (links(fields["约束"][0], "K") & k_ids):
            fails.append(f"决策 {did} 的「约束」没有链到任何已列出的约束（#K..）")
        if not EV_REF_RE.search(body):
            fails.append(f"决策 {did} 没有挂证据")

    # 4 核心思想
    ideas = section_html(inner, "ideas") or ""
    arts = tagged(ideas, "article", "idea")
    idea_ids = set()
    if not (2 <= len(arts) <= 4):
        fails.append(f"核心思想为 {len(arts)} 条，规范要求 2–4 条")
    for attrs, body in arts:
        iid = attr(attrs, "id") or "?"
        idea_ids.add(iid)
        if not re.fullmatch(r"I\d+", iid):
            fails.append(f"核心思想 id 应为 I1、I2…，实际为「{iid}」")
        if attr(attrs, "data-intent") not in INTENTS:
            fails.append(f"核心思想 {iid} 的 data-intent 必须是 declared / inferred")
        if "UNKNOWN" in text_of(body):
            fails.append(f"核心思想 {iid} 含 UNKNOWN：无法判断的意图不能作为核心思想")
        refs = set(EV_REF_RE.findall(body))
        if len(refs) < 2:
            fails.append(f"核心思想 {iid} 只挂了 {len(refs)} 条证据：一处是写法，多处才是思想（需 ≥2）")
        else:
            paths = {evidence[r].get("path") for r in refs if r in evidence and evidence[r].get("kind") == "file"}
            if len(paths) < 2:
                fails.append(f"核心思想 {iid} 的证据只来自 {len(paths)} 个文件，需来自 ≥2 个不同文件")

    # 6 偏离
    devs = section_html(inner, "deviations") or ""
    items = tagged(devs, "li", "deviation")
    d_ids = set()
    if not items and "未发现偏离" not in text_of(devs):
        fails.append("意图与实现的偏离：既没有 li.deviation 条目，也没有写明「未发现偏离」")
    for attrs, body in items:
        did = attr(attrs, "id") or "?"
        d_ids.add(did)
        if not re.fullmatch(r"D\d+", did):
            fails.append(f"偏离条目 id 应为 D1、D2…，实际为「{did}」")
        if not (links(body, "I") & idea_ids):
            fails.append(f"偏离 {did} 没有链到它违背的核心思想（#I..）")
        if not EV_REF_RE.search(body):
            fails.append(f"偏离 {did} 没有挂证据")

    # 7 评价
    vers = section_html(inner, "verdicts") or ""
    arts = tagged(vers, "article", "verdict")
    judged = set()
    if not arts:
        fails.append("评价：没有任何 article.verdict 条目")
    for attrs, body in arts:
        vid = attr(attrs, "id") or "?"
        fit = attr(attrs, "data-fit")
        if fit not in FITS:
            fails.append(f"评价 {vid} 的 data-fit 必须是 fit / risky / unfit")
        fields = dl_fields(body)
        for f in VERDICT_FIELDS:
            if f not in fields or not fields[f][1]:
                fails.append(f"评价 {vid} 缺少或空着字段「{f}」")
        if "评价对象" in fields:
            targets = links(fields["评价对象"][0], "DEC") | links(fields["评价对象"][0], "I")
            if not (targets & (dec_ids | idea_ids)):
                fails.append(f"评价 {vid} 的「评价对象」没有链到已列出的决策（#DEC..）或思想（#I..）")
            judged |= targets
        if fit in FITS and "适配度" in fields and FITS[fit] not in fields["适配度"][1]:
            fails.append(f"评价 {vid} 的 data-fit={fit} 与「适配度」文字不一致（应含「{FITS[fit]}」）")
        if "依据" in fields:
            basis = fields["依据"][0]
            if not EV_REF_RE.search(basis):
                fails.append(f"评价 {vid} 的「依据」没有挂证据")
            if fit in ("risky", "unfit") and not ((links(basis, "D") & d_ids) | (links(basis, "K") & k_ids)):
                fails.append(f"评价 {vid} 判为「{FITS[fit]}」，但「依据」没有链到任何偏离（#D..）或约束（#K..）")

    unjudged = sorted((dec_ids | idea_ids) - judged)
    if unjudged and arts:
        notes.append("以下决策 / 思想没有评价（允许，但请确认是有意略过）：" + "、".join(unjudged))
    return fails, notes


def section_html(html, sec_id):
    m = re.search(r'<section id="%s"[^>]*>(.*?)</section>' % re.escape(sec_id), html, re.S)
    return m.group(1) if m else None


def check_evidence(report, repo):
    r = subprocess.run([sys.executable, str(VERIFY), report, repo], capture_output=True, text=True)
    out = (r.stdout or "") + (r.stderr or "")
    return r.returncode == 0, out.strip().splitlines()


def check_structure(html):
    fails, notes = [], []

    for sec_id, name in L1_SECTIONS:
        if section_html(html, sec_id) is None:
            fails.append(f"上手层缺少区块：{name}（#{sec_id}）")
    for sec_id, name in L2_SECTIONS:
        if section_html(html, sec_id) is None:
            fails.append(f"参考层缺少区块：{name}（#{sec_id}）")

    if not re.search(r'<details[^>]*class="[^"]*refs', html):
        fails.append("参考层没有用 <details> 折叠")
    # 参考层各区块必须落在 details 里
    m = re.search(r'<details[^>]*class="[^"]*refs[^"]*"[^>]*>(.*?)</details>', html, re.S)
    if m:
        inner = m.group(1)
        for sec_id, name in L2_SECTIONS:
            if f'id="{sec_id}"' not in inner:
                fails.append(f"参考层区块：{name}（#{sec_id}）不在折叠层内")
    else:
        notes.append("未能定位参考层内容（details 结构异常）")

    flows = section_html(html, "core-flows")
    if flows is None:
        fails.append("核心流程区块缺失，无法统计图数")
    else:
        blocks = MERMAID_RE.findall(flows)
        if not (3 <= len(blocks) <= 5):
            fails.append(f"核心流程时序图数量为 {len(blocks)}，规范要求 3–5 张")
        h3s = re.findall(r"<h3[^>]*>(.*?)</h3>", flows, re.S)
        p_evs = re.findall(r'<p class="ev"[^>]*>(.*?)</p>', flows, re.S)
        marked = [p for p in p_evs if CRITERIA_RE.search(p)]
        if len(marked) < len(blocks):
            fails.append(f"有 {len(blocks)} 张核心流程图，但只找到 {len(marked)} 处「命中判据 C1–C4」标注")
        if len(h3s) != len(blocks):
            notes.append(f"核心流程标题数 {len(h3s)} 与图数 {len(blocks)} 不一致")
        for h in h3s:
            if re.fullmatch(r"\s*(核心流程|时序图|接口时序图)\s*", re.sub(r"<[^>]+>", "", h)):
                fails.append("存在「核心流程」这类没有说清用途的泛标题")

    cov = section_html(html, "coverage")
    if cov is None:
        fails.append("缺少覆盖范围声明")
    else:
        text = re.sub(r"<[^>]+>", "", cov)
        if len(text) < 80:
            fails.append("覆盖范围声明内容过少（应写明已覆盖 / 未展开 / 原因 / 下一步）")
        for kw in ("已覆盖", "未展开"):
            if kw not in text:
                fails.append(f"覆盖范围声明缺少「{kw}」")

    unk = section_html(html, "unknowns")
    if unk is None:
        fails.append("缺少未确认清单")
    else:
        items = re.findall(r"<li>", unk)
        if not items:
            notes.append("未确认清单为空列表（仓库信息很全时可能是正常的，请人工确认）")
        body_all = re.sub(r"<[^>]+>", "", html)
        if "UNKNOWN" in body_all and not items:
            fails.append("正文出现 UNKNOWN，但未确认清单没有条目")

    if not re.search(r'<script[^>]*id=["\']evidence-index["\']', html):
        fails.append("缺少 #evidence-index 证据索引块")

    f_i, n_i = check_interpretation(html)
    fails.extend(f_i)
    notes.extend(n_i)
    return fails, notes


def check_mermaid_raw(html):
    bad = []
    for i, block in enumerate(MERMAID_RE.findall(html), 1):
        for n, line in enumerate(block.splitlines(), 1):
            if BARE_LT_RE.search(line) or BARE_AMP_RE.search(line):
                bad.append(f"第 {i} 张图第 {n} 行含裸 '<' 或 '&'：{line.strip()[:70]}")
    return bad


BROWSERS = [
    os.environ.get("CHROME_PATH", ""),
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Chromium.app/Contents/MacOS/Chromium",
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
]
HARNESS = """
<div id="__check_out"></div>
<script type="module">
const out = document.getElementById('__check_out');
const log = [];
try {
  const mod = await import('https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.esm.min.mjs');
  const mermaid = mod.default;
  mermaid.initialize({ startOnLoad: false, theme: 'neutral', securityLevel: 'loose' });
  const els = [...document.querySelectorAll('pre.mermaid')];
  for (let i = 0; i < els.length; i++) {
    try {
      await mermaid.render('chk' + i, els[i].textContent);
      log.push('OK ' + (i + 1));
    } catch (e) {
      log.push('FAIL ' + (i + 1) + ' :: ' + String(e && e.message || e).split('\\n').slice(0, 3).join(' | '));
    }
  }
} catch (e) { log.push('CDN_FAIL :: ' + e.message); }
out.textContent = JSON.stringify(log);
</script>
"""


def find_browser():
    for b in BROWSERS:
        if b and os.path.exists(b):
            return b
    for name in ("google-chrome", "google-chrome-stable", "chromium", "chromium-browser", "msedge", "microsoft-edge"):
        p = shutil.which(name)
        if p:
            return p
    return None


def check_render(report):
    browser = find_browser()
    if not browser:
        return None, "未找到本机浏览器（可设 CHROME_PATH 指定），渲染门跳过"
    html = pathlib.Path(report).read_text(encoding="utf-8")
    html = re.sub(r'<script type="module">.*?</script>\s*</body>', "", html, flags=re.S)
    html = html.replace("</body></html>", "") + HARNESS + "</body></html>"
    with tempfile.TemporaryDirectory() as td:
        harness = pathlib.Path(td) / "render-check.html"
        harness.write_text(html, encoding="utf-8")
        try:
            r = subprocess.run(
                [browser, "--headless=new", "--disable-gpu", "--no-sandbox",
                 f"--user-data-dir={td}/profile", "--virtual-time-budget=30000", "--dump-dom",
                 harness.as_uri()],
                capture_output=True, text=True, timeout=180)
        except Exception as e:  # 浏览器启动失败
            return None, f"浏览器无法启动（{e}），渲染门跳过"
    dom = r.stdout or ""
    m = re.search(r'<div id="__check_out">(.*?)</div>', dom, re.S)
    if not m:
        return None, "渲染检查未取到结果（页面可能未执行脚本），渲染门跳过"
    raw = m.group(1).replace("&quot;", '"').strip()
    try:
        log = json.loads(raw)
    except json.JSONDecodeError:
        return None, f"渲染检查输出无法解析，渲染门跳过：{raw[:120]}"
    if any(str(x).startswith("CDN_FAIL") for x in log):
        return None, "加载不到 Mermaid CDN（离线？），渲染门跳过"
    fails = [x for x in log if str(x).startswith("FAIL")]
    return (len(fails) == 0), f"{len(log) - len(fails)}/{len(log)} 张图渲染成功" + ("" if not fails else "；失败：" + "; ".join(fails))


def main():
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument("report", nargs="?")
    ap.add_argument("repo", nargs="?")
    ap.add_argument("--render", action="store_true")
    ap.add_argument("-h", "--help", action="store_true")
    a = ap.parse_args()
    if a.help or not a.report:
        print(__doc__)
        return 0 if a.help else 2
    report = os.path.abspath(a.report)
    if not os.path.isfile(report):
        print(f"报告不存在: {report}", file=sys.stderr)
        return 2
    repo = os.path.abspath(a.repo) if a.repo else str(pathlib.Path(report).parent.parent)
    html = pathlib.Path(report).read_text(encoding="utf-8")

    print(f"产出后检查: {report}")
    print(f"仓库根:     {repo}\n")

    failed = False

    ok, lines = check_evidence(report, repo)
    failed |= not ok
    print(f"[A] 证据门：{'通过' if ok else '失败'}")
    for l in lines:
        if "失败" in l or l.strip().startswith("-") or "索引条目" in l or "Mermaid 图" in l:
            print("    " + l.strip())
    fails_b, notes = check_structure(html)
    failed |= bool(fails_b)
    print(f"\n[B] 结构门：{'通过' if not fails_b else '失败'}")
    for f in fails_b:
        print("    ✗ " + f)
    for n in notes:
        print("    · " + n)
    print("\n[C] 渲染门：", end="")
    if a.render:
        ok_r, msg = check_render(report)
        if ok_r is None:
            print(f"跳过（{msg}）")
        else:
            failed |= not ok_r
            print(("通过" if ok_r else "失败") + f"（{msg}）")
    else:
        print("跳过（未加 --render；交付前建议跑一次）")

    print("\n" + ("检查通过，可以交付。" if not failed else "检查未通过：修完再跑，不要跳过。"))
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
