# 技术栈事实源地图

这份表回答的是**「去哪个文件读事实」**，不是「用正则扫出什么」。路由、环境变量、端口都需要理解语义，只能读代码；正则换个框架就失效，一律不用。

先看 `collect_facts.py` 的输出，再用本表定位要读的文件。

## 通用：不看语言就能定的事实

| 想知道 | 读哪里 |
| --- | --- |
| 仓库边界、是否 monorepo | 顶层目录 + 各子目录的清单文件是否各自独立可部署 |
| 依赖与版本 | 清单文件看声明范围，**锁文件看实际版本**；两者不一致时以锁文件为准 |
| 怎么构建 / 怎么跑 | `Makefile`、`justfile`、`Taskfile.yml`、清单里的 `scripts`、CI 配置 |
| 部署到哪 | CI/CD 配置 + 容器/部署描述文件（`Dockerfile`、`firebase.json`、`vercel.json`、`app.yaml`、`*.tf`…） |
| 需要哪些外部服务 | `docker-compose*.yml` 的 `services` 最可靠；其次是配置文件的连接串默认值 |
| 需要哪些配置项 | 配置类文件（`.env*`、`config.*`、`application.*`）+ 代码里的读取调用点 |
| 数据模型 | 迁移目录、schema 文件、ORM 实体定义 |

## 按清单文件命中

| 清单文件 | 额外能读到 |
| --- | --- |
| `package.json` | `scripts`（启动/构建真相）、`engines`（Node 版本）、依赖分组 |
| `go.mod` | 模块路径、Go 版本、框架依赖（gin/echo/fiber/chi/goravel…） |
| `pyproject.toml` / `requirements.txt` | `requires-python`、依赖、构建后端 |
| `pom.xml` / `build.gradle*` | Java 版本、Spring Boot 版本、插件 |
| `Cargo.toml` | edition、`rust-version`、依赖 |
| `Gemfile` / `composer.json` / `*.csproj` / `mix.exs` | 同构：语言版本 + 依赖 |

## 读代码时按这些形态找（线索，不是正则清单）

路由与入口的写法因框架而异，下面是**读代码时的形态提示**，命中哪个取决于框架：

| 信号 | 去哪读 |
| --- | --- |
| Spring / Nest / ASP.NET | `@RequestMapping`、`@Controller`、注解/装饰器扫描 |
| Express / Koa / Fastify | 可能是 `router.get(...)`，也可能是**声明式路由表**（数组/对象常量）；后者没有方法调用形态 |
| Go（gin/echo/fiber/chi） | 多在 `main.go` 或独立的 `router`/`routes` 包；注意方法名大写 `r.GET(` |
| Go（Goravel/Laravel 风格） | `routes/*.go`，由 `registerXxxRoutes()` 集中注册 |
| Django | `urls.py` 的 `urlpatterns`；DRF 再看 `routers.py` |
| Rails / Laravel PHP | 目录约定 + `routes/*.php` / `config/routes.rb` |
| Next / Nuxt | 文件即路由：`pages/` 或 `app/` 目录结构就是路由表 |
| go-zero / gRPC / 代码生成 | 路由在 `.api`/`.proto` 描述文件，产物是生成代码 |
| 依赖注入（wire/fx/Spring） | 入口可能在容器装配处，不在 `main` 里 |

配置读取同理：`process.env.X`、`os.Getenv`、`config.Env(...)`、`@Value("${...}")`、`viper.Get`、`settings.X`、`Env::var`……名字是各家自己的，别按单一形态去搜。

## 端口与配置语义

- 端口只能来自：配置声明、`listen(...)` 调用、容器端口映射、CI 环境。四者都没有 → `UNKNOWN`。
- 环境变量只记录**出现位置**（`file:line`）与同处的默认值。语义没有文档或校验代码佐证时一律 `UNKNOWN`。
- 框架约定值（如某些框架默认 8080）不算证据，除非仓库里写了。
